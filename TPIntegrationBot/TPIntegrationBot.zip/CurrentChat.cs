﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TPIntegrationBot
{
    public class CurrentChat
    {
        public int Id;
        public string Project;
        public string Title;
        public string Entity;
        public string Description;
        public CurrentChat()
        {

        }
    }
}
