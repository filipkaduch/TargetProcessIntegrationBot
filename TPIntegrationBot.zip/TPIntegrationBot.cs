using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Connector;
using Microsoft.Bot.Schema;
using System.Runtime.Serialization.Json;
using System.Collections.Specialized;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Net.Http;
using RestSharp;
using RestSharp.Authenticators;
using modelsAlias = Microsoft.Bot.Connector.Teams.Models;
using Microsoft.Bot.Connector.Teams;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using System.Configuration;
using System.Globalization;
using AdaptiveCards;

namespace TPIntegrationBot
{
    // Represents a bot that processes incoming activities.
    // For each user interaction, an instance of this class is created and the OnTurnAsync method is called.
    // This is a Transient lifetime service. Transient lifetime services are created
    // each time they're requested. For each Activity received, a new instance of this
    // class is created. Objects that are expensive to construct, or have a lifetime
    // beyond the single turn, should be carefully managed.


    public class AttachmentsBot : ActivityHandler
    {
        private static string chatId = "";
        private static string selectedEntity = "";
        private static string entityName = "";
        private static string projectName = "";
        private static string userName = "";
        private static string entityDescription = "";
        private static string fileUrl = "";
        private static int dialogCounter = 0;
        private static int openingDialogCounter = 0;
        private static List<string> attachementsUrl = new List<string>();
        private static List<string> previewUrl = new List<string>();
        private static bool hasBegun = false;
        public string serviceUrl = "";
        public static string localDownloadUrl = "";
        private static List<Payload> currentPayloads = new List<Payload>();
        private static List<string> adminList = new List<string>();
        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            
            await SendWelcomeMessageAsync(turnContext, cancellationToken);
            //await DisplayOptionsAsync(turnContext, cancellationToken);
        }
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            Activity replyAdmin = new Activity();
            if (SettingsStructure.FirstTimeOpened == "false")
            {                
                
                var adminNameCheck = turnContext.Activity.From.Name;
                var checkedName = SettingsStructure.AdminName.FirstOrDefault(r => r == adminNameCheck);
                var adminTxt = turnContext.Activity.Text;

                if (adminTxt.ToLower() == "admin" && checkedName != null)
                {
                    var processedPay = currentPayloads.FirstOrDefault(r => r.Id == turnContext.Activity.From.Name);
                    if(processedPay != null)
                        currentPayloads.RemoveAll(s => s.Id == turnContext.Activity.From.Name);
                    SettingsStructure.FirstTimeOpened = "true";
                }else if(adminTxt.ToLower() == "admin" && checkedName == null)
                {
                    var processedPay = currentPayloads.FirstOrDefault(r => r.Id == turnContext.Activity.From.Name);
                    if (processedPay != null)
                        currentPayloads.RemoveAll(s => s.Id == turnContext.Activity.From.Name);
                    replyAdmin = ProcessAdminRights(turnContext);
                    await turnContext.SendActivityAsync(replyAdmin, cancellationToken);
                }
            }

            if (SettingsStructure.FirstTimeOpened == "true")
            {
                var replyCard = turnContext.Activity;
                
                MicrosoftAppCredentials.TrustServiceUrl(turnContext.Activity.ServiceUrl);
                MicrosoftAppCredentials mscred = new MicrosoftAppCredentials("cc7ad832-acee-4df4-ac3a-471e180785ec", "blcKCSHN7()cbceJM2218$*");
                ConnectorClient connector = new ConnectorClient(new System.Uri(turnContext.Activity.ServiceUrl), mscred);
                
                var openingDialog = ProcessOpening(turnContext);
                await connector.Conversations.SendToConversationAsync(openingDialog, cancellationToken);                
                //await turnContext.SendActivityAsync(MessageFactory.Attachment(CreateAdaptiveCardAttachment(turnContext)), cancellationToken);              
            }
            else if(replyAdmin.Text == "" || replyAdmin.Text == null)
            {
                var processedPay = currentPayloads.FirstOrDefault(r => r.Id == turnContext.Activity.From.Name);
                var rstText = turnContext.Activity.Text;

                if (rstText != null)
                {
                    if (rstText.ToLower() == "reset")
                    {
                        currentPayloads.RemoveAll(s => s.Id == turnContext.Activity.From.Name);
                        ResetReport(turnContext.Activity);
                    }
                }
                if(processedPay == null)
                {
                    await SendWelcomeMessageAsync(turnContext, cancellationToken);
                }
                else if (processedPay.HasBegun == false)
                {
                    await SendWelcomeMessageAsync(turnContext, cancellationToken);
                }
                else
                {
                    var reply = ProcessInput(turnContext);
                    await turnContext.SendActivityAsync(reply, cancellationToken);
                }
            }
        }

        private static void ResetReport(IMessageActivity activity)
        {
            var payloadToReset = currentPayloads.FirstOrDefault(r => r.Id == activity.From.Name);
            if (payloadToReset != null)
            {
                payloadToReset.DialogCounter = 0;
                payloadToReset.Entity = "";
                payloadToReset.Project = "";
                payloadToReset.Text = "";
                payloadToReset.Title = "";
                payloadToReset.HasBegun = false;
                payloadToReset.Category.Clear();
            }
            dialogCounter = 0;
            selectedEntity = "";
            projectName = "";
            entityDescription = "";
            attachementsUrl.Clear();
            entityName = "";
            hasBegun = false;
        }

        private static async Task DisplayOptionsAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            Payload currentPayload = new Payload();
            currentPayloads.Add(currentPayload);
            currentPayload.Id = turnContext.Activity.From.Name;
            currentPayload.DialogCounter = 0;
            currentPayload.HasBegun = true;
            currentPayload.Category = new List<string>();
            

            var reply = turnContext.Activity.CreateReply();       

            // Create a HeroCard with options for the user to interact with the bot.
            var card = new HeroCard
            {
                Text = "What kind of entity would you like to create?",
                Buttons = new List<CardAction>
                {
                    new CardAction(ActionTypes.ImBack, title: "1. Bug", value: "1"),
                    new CardAction(ActionTypes.ImBack, title: "2. Request", value: "2"),
                    new CardAction(ActionTypes.ImBack, title: "3. User story", value: "3"),
                },
            };

            // Add the card to our reply.
            reply.Attachments = new List<Attachment>() { card.ToAttachment() };

            await turnContext.SendActivityAsync(reply, cancellationToken);
        }

        // Greet the user and give them instructions on how to interact with the bot.
        private static async Task SendWelcomeMessageAsync(ITurnContext turnContext, CancellationToken cancellationToken)
        {
            await DisplayOptionsAsync(turnContext, cancellationToken);
            hasBegun = true;
        }

        private static Attachment CreateAdaptiveCardAttachment(ITurnContext turnContext)
        {
            var adaptiveCardJson = File.ReadAllText("AdminSettingsCard.json");
            AdaptiveCard ac = new AdaptiveCard(adaptiveCardJson);

            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,//"application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }

        private static Activity ProcessAdminRights(ITurnContext turnContext)
        {
            var reply = turnContext.Activity.CreateReply();
            reply.Text = "You do not have permission to edit admin settings!";
            return reply;
        }

        private static Activity ProcessOpening(ITurnContext turnContext)
        {
            const string greetingText = "Welcome to TargetProcess integration Bot! Please continue with answering few questions to setup this bot. ";
            const string webhookText = "Please provide your TargetProcess URL: ";
            const string projectIdText = "Please provide names and ID's to your TargetProcess projects<br></br>(ProjectName1 ID1 ProjectName2 ID2 ...):";
            const string checkText = "Are you satisfied with your settings: ";
            const string closingText = "Alright, you are ready to use this bot for reporting entities in TargetProcess! Wake up this bot with any message. ";
            const string adminText1 = "Would you like to promote ";
            const string adminText2 = " to a new Bot admin?";
            const string adminDeclineText = "Promoting user to admin declined!";
            const string adminPromoteCheckText = " is already a Bot admin!";

            var reply = turnContext.Activity.CreateReply();
            

            switch (openingDialogCounter)
            {
                case 0:
                    {
                        var adaptiveCardJson = File.ReadAllText("AdminSettingsCard.json");
                        AdaptiveCardParseResult result = AdaptiveCard.FromJson(adaptiveCardJson);

                        AdaptiveCard cardAc = result.Card;
                        var adaptiveCardAttachment = new Attachment()
                        {
                            ContentType = "application/vnd.microsoft.card.adaptive",
                            Content = cardAc,
                        };

                        reply.Attachments = new List<Attachment>() { adaptiveCardAttachment };
                        openingDialogCounter++;
                        break;
                    }
                case 1:
                    {
                        dynamic answers = (JObject)turnContext.Activity.Value;
                        string tpUrl = answers.tpSetUrl.ToString();
                        
                        string basicAdminName = turnContext.Activity.From.Name;
                        string basicAdminNameCheck = SettingsStructure.AdminName.FirstOrDefault(r => r == basicAdminName);
                        adminList.Add(basicAdminName);

                        string adminName = answers.adminSetRights.ToString();
                        string adminNameCheck = SettingsStructure.AdminName.FirstOrDefault(r => r == adminName);
                        if(adminName != null && adminName != "" && adminNameCheck == null)
                        {
                            adminList.Add(adminName);
                        }


                        string listNames = answers.projectSetNames.ToString();
                        string listIds = answers.projectSetId.ToString();

                        List<string> tempListNames = listNames.Split(' ').ToList();
                        List<string> tempListIds = listIds.Split(' ').ToList();

                        string stringNames = "";
                        string stringIds = "";

                        foreach(var s in tempListNames)
                        {
                            stringNames += s;
                            stringNames += " ";
                        }
                        foreach(var s in tempListIds)
                        {
                            stringIds += s;
                            stringIds += " ";
                        }

                        foreach (var n in SettingsStructure.ProjectNames)
                        {
                            tempListNames.Add(n);
                        }
                        foreach (var id in SettingsStructure.ProjectIds)
                        {
                            tempListIds.Add(id);
                        }

                        if (answers.tpSetUrl.ToString() != "")
                            SettingsStructure.TargetProcessUrl = answers.tpSetUrl.ToString();
                        if(tempListNames.ElementAt(0) != "")
                            SettingsStructure.ProjectNames = new List<string>(tempListNames);
                        if(tempListIds.ElementAt(0) != "")
                            SettingsStructure.ProjectIds = new List<string>(tempListIds);

                        SettingsStructure.AdminName = new List<string>(adminList);

                        if (stringNames != "" && stringIds != "" && tpUrl != "")
                        {
                            var card = new HeroCard
                            {
                                Title = checkText,
                                Text = $"<b>TargetProcess URL:</b> " + SettingsStructure.TargetProcessUrl + $" <br></br><b>Project names:</b> " + stringNames + $"<br></br><b>Project Ids:</b> " + stringIds + $"<br></br>",
                                Buttons = new List<CardAction>
                            {
                                new CardAction(ActionTypes.ImBack, title: "Confirm", value: "confirm"),
                                new CardAction(ActionTypes.ImBack, title: "Delete", value: "delete"),
                            },
                            };
                            reply.Attachments = new List<Attachment>() { card.ToAttachment() };
                        }
                        else if(adminName != null && adminName != "" && adminNameCheck == null)
                        {
                            var card = new HeroCard
                            {
                                Text = adminText1 + adminName + adminText2,
                                Buttons = new List<CardAction>
                            {
                                new CardAction(ActionTypes.ImBack, title: "Confirm", value: "confirm"),
                                new CardAction(ActionTypes.ImBack, title: "Decline", value: "decline"),
                            },
                            };
                            reply.Attachments = new List<Attachment>() { card.ToAttachment() };
                        }
                        else if(adminNameCheck != null)
                        {
                            reply.Text = adminName + adminPromoteCheckText;
                            openingDialogCounter = 0;
                            SettingsStructure.FirstTimeOpened = "false";
                        }                        
                        openingDialogCounter++;
                        break;
                    }
                //case 2:
                //    {
                //        var listResponse = turnContext.Activity.Text;
                //        List<string> tempList = listResponse.Split(' ').ToList();
                //        List<string> tempListNames = new List<string>();
                //        List<string> tempListIds = new List<string>();

                //        for (int i = 0; i < tempList.Count; i++)
                //        {
                //            if (i % 2 == 0)
                //            {
                //                tempListNames.Add(tempList.ElementAt(i));
                //            }
                //            else
                //            {
                //                tempListIds.Add(tempList.ElementAt(i));
                //            }
                //        }
                //        SettingsStructure.ProjectNames = new List<string>(tempListNames);
                //        SettingsStructure.ProjectIds = new List<string>(tempListIds);
                //        string stringNames = "";
                //        string stringIds = "";
                //        for (int i = 0; i < SettingsStructure.ProjectNames.Count; i++)
                //        {
                //            stringNames += SettingsStructure.ProjectNames.ElementAt(i);
                //            stringNames += " ";
                //            stringIds += SettingsStructure.ProjectIds.ElementAt(i);
                //            stringIds += " ";
                //        }

                //        openingDialogCounter++;
                //        break;
                //    }
                case 2:
                    {
                        if (turnContext.Activity.Text == "delete")
                        {
                            openingDialogCounter = 0;

                        }
                        else if (turnContext.Activity.Text == "confirm")
                        {
                            reply.Text = $"{closingText}";
                            openingDialogCounter = 0;
                            SettingsStructure.FirstTimeOpened = "false";
                            SettingsStructure toJson = new SettingsStructure();
                            toJson._FirstTimeOpened = SettingsStructure.FirstTimeOpened;
                            toJson._AdminName = new List<string>(SettingsStructure.AdminName);
                            toJson._TargetProcessUrl = SettingsStructure.TargetProcessUrl;
                            toJson._ProjectIds = new List<string>(SettingsStructure.ProjectIds);
                            toJson._ProjectNames = new List<string>(SettingsStructure.ProjectNames);
                            string json = JsonConvert.SerializeObject(toJson);
                            System.IO.File.WriteAllText(@"C:\Users\fkaduch\source\repos\TPIntegrationBot\TPIntegrationBot\UserSettings.json", json);                           
                        }
                        else if(turnContext.Activity.Text == "decline")
                        {
                            reply.Text = adminDeclineText;
                            openingDialogCounter = 0;
                            SettingsStructure.FirstTimeOpened = "false";
                        }
                        else
                        {
                            reply.Text = "Please select either confirm or delete option!";
                        }
                        break;
                    }
            }
            return reply;
        }

        // Given the input from the message, create the response.
        private static Activity ProcessInput(ITurnContext turnContext)
        {
            var activity = turnContext.Activity;
            var reply = activity.CreateReply();
            
            if (activity.Attachments != null && activity.Attachments.Any())
            {
                // We know the user is sending an attachment as there is at least one item
                // in the Attachments list.
                HandleIncomingAttachment(activity, reply);
            }
            else
            {
                HandleOutgoingAttachment(activity, reply);
            }

            return reply;
        }


        private static void HandleOutgoingAttachment(IMessageActivity activity, IMessageActivity reply)
        {
            const string descriptionText = "Add description to your";
            const string titleText = "Add title to your";
            const string pictureText = "Send a picture as an attachement to your";
            var processedPayload = currentPayloads.FirstOrDefault(pay => pay.Id == activity.From.Name);

            if (processedPayload.DialogCounter == 2)
            {
                processedPayload.Title = activity.Text;
                processedPayload.DialogCounter++;
                reply.Text = $"{descriptionText} {selectedEntity}:";
                dialogCounter++;
            }
            else if (processedPayload.DialogCounter == 3)
            {
                processedPayload.Text = activity.Text + $"<br></br>";
                processedPayload.DialogCounter++;
                reply.Text = $"{pictureText} {selectedEntity}:";
                dialogCounter++;
            }
            else if (processedPayload.DialogCounter == 4)
            {
                
                if(activity.Text == "Submit")
                {
                    //Payload payload = new Payload()
                    //{
                    //    Id = 
                    //    Entity = selectedEntity,
                    //    Project = projectName,
                    //    Title = entityName,
                    //    Username = userName,
                    //    Text = entityDescription,
                    //    Category = attachementsUrl
                    //};

                    PostMessage(processedPayload);
                    reply.Text = $"Thanks "+ processedPayload.Id +" for reporting "+ processedPayload.Entity;
                    var itemToRemove = currentPayloads.Single(r => r.Id == activity.From.Name);
                    currentPayloads.Remove(itemToRemove);
                }
                else
                {
                    ResetReport(activity);
                    reply.Text = "Report deleted!";
                }               
            }
            else if (processedPayload.DialogCounter == 0)
            {
                if (activity.Text.StartsWith("1"))
                {
                    processedPayload.Entity = "Bug";
                    processedPayload.DialogCounter++;
                    selectedEntity = "Bug";
                    dialogCounter++;
                }
                else if (activity.Text.StartsWith("2"))
                {
                    processedPayload.Entity = "Request";
                    processedPayload.DialogCounter++;
                    selectedEntity = "Request";
                    dialogCounter++;
                }
                else if (activity.Text.StartsWith("3"))
                {
                    processedPayload.Entity = "User Story";
                    processedPayload.DialogCounter++;
                    selectedEntity = "User Story";
                    dialogCounter++;
                }
                else
                {
                    // The user did not enter input that this bot was built to handle.
                    reply.Text = "Please select an entity from the suggested type choices";
                }
                if(processedPayload.DialogCounter == 1)
                {
                    List<CardAction> projectButtons = new List<CardAction>();

                    for (int i = 0; i < SettingsStructure.ProjectNames.Count; i++)
                    {
                        projectButtons.Add(new CardAction(ActionTypes.ImBack, title: SettingsStructure.ProjectNames.ElementAt(i), value: SettingsStructure.ProjectIds.ElementAt(i)));
                    }

                    var card = new HeroCard
                    {
                        Text = $"Which project has {selectedEntity}:",
                        Buttons = new List<CardAction>(projectButtons),
                    };
                    reply.Attachments = new List<Attachment>() { card.ToAttachment() };
                }
            }else if(processedPayload.DialogCounter == 1)
            {
                processedPayload.Project = activity.Text;
                processedPayload.DialogCounter++;
                reply.Text = $"{titleText} {selectedEntity}:";
                dialogCounter++;
            }
        }

        public static void PostMessage(Payload payload)
        {
            string payloadJson = JsonConvert.SerializeObject(payload);
            //var token = "?NTM1OnZRMGo5NWJJSVhya3BhM0VsK0FEeXMzL0dONG51SFFNSkhVV0l3NnJIYWM9==";
            var restClient = new RestClient(SettingsStructure.TargetProcessUrl); 
            
            string token = "";
            HttpClient client = new HttpClient();           
            client.BaseAddress = new Uri(SettingsStructure.TargetProcessUrl+ "api/v1/");
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            string query = "";

            switch (payload.Entity)
            {
                case "Bug":
                    {
                        query = "bugs";
                        break;
                    }
                case "User story":
                    {
                        query = "userstories";
                        break;
                    }
                case "Request":
                    {
                        query = "requests";
                        break;
                    }
            }
            
            HttpContent payloadTP = new StringContent("{Name:'"+ payload.Title +"',Description:'"+ payload.Text +"',Project:{Id:"+ payload.Project +"}}", Encoding.UTF8, "application/json");
            string authentication = Convert.ToBase64String(Encoding.ASCII.GetBytes("filip.kaduch@instarea.com:magduska89"));
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authentication);
            string returnedEntity = "";
            string entityId = "";
            int entNum = 0;
            //query += "?token=NTM1OjUzOUE5OUUzQjdDN0YwREE4REVGQzIxOEY4MEI4QjBD==";
            HttpResponseMessage response = client.PostAsync(query, payloadTP).Result;
            if (response.IsSuccessStatusCode)
            {
                returnedEntity = response.Content.ReadAsStringAsync().Result;
                var splitId = returnedEntity.Split("Id\":");
                foreach (char c in splitId[1])
                {
                    if (c == ',')
                        break;
                    else
                    {
                        entityId += c;
                    }
                }
                entNum = Int32.Parse(entityId);
            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }


            foreach (var localUrl in payload.Category)
            {
                var nameOfFile = localUrl.Split("\\");
                int lengthOfList = nameOfFile.Length;
                var reportImage = nameOfFile.ElementAt((lengthOfList - 1));
                string typeImage = "image/";
                var type = reportImage.Split(".");
                typeImage += type[1];
                var pathToFile = @"" + localUrl;

                var file = new AttachmentFile()
                {
                    FileName = reportImage,
                    ContentType = typeImage,
                    Content = new MemoryStream(File.ReadAllBytes(pathToFile))
                };

                UploadAttachment(restClient, token, file, entNum);
            }
            //using (WebClient client = new WebClient())
            //try
            //{
            //    WebClient client = new WebClient();

            //    NameValueCollection data = new NameValueCollection();
            //    data["payload"] = payloadJson;
            //    client.UseDefaultCredentials = true;
            //    client.Headers[HttpRequestHeader.ContentType] = "application/json";
            //    var res = client.UploadString(SettingsStructure.TargetProcessWebhook, "POST", payloadJson);
            //}
            //catch (Exception ex)
            //{
            //    var exc = ex;
            //}
            attachementsUrl.Clear();
            hasBegun = false;
        }

        public class Request
        {
            public string Description { get; set; }

            public string Name { get; set; }
            public Project Project { get; set; }

            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.String.Format(System.String,System.Object[])")]
            public override string ToString() =>
                $"{base.ToString()}, {nameof(Description)}: {Description}, {nameof(Project)}: {{{Project}}}";
        }
        public class Project
        {
            public int Id { get; set; }
        }


        private static Attachment UploadAttachment(RestClient restClient, string token, AttachmentFile file, int id)
        {
            restClient.Authenticator = new HttpBasicAuthenticator("filip.kaduch@instarea.com", "magduska89");
            var restRequest = new RestRequest("UploadFile.ashx" + token, Method.POST);
            restRequest.AddHeader("Content-Type", "multipart/form-data");
            restRequest.AddFile("attachment", file.Content.ToArray(), file.FileName, file.ContentType);
            restRequest.AddParameter("generalId", id);
            var response = restClient.Execute<Attachment>(restRequest);
            Console.WriteLine(response.StatusCode);
            Console.WriteLine(response.Content);
            return response.Data;
        }

        private static void HandleIncomingAttachment(IMessageActivity activity, IMessageActivity reply)
        {
            var processedPay = currentPayloads.FirstOrDefault(r => r.Id == activity.From.Name);
            string url = "";
            processedPay.Category = new List<string>();
            foreach (var file in activity.Attachments)
            {
                // Determine where the file is hosted.
                var remoteFileUrl = ((JObject)file.Content)["downloadUrl"].ToString();
                url = remoteFileUrl;
                var checkUrl = file.ContentUrl;
                fileUrl = checkUrl.Replace(" ","%20");
                // Save the attachment to the system temp directory.
                localDownloadUrl = Path.Combine(Path.GetTempPath(), file.Name);
                
                try
                {
                    var webClient = new WebClient();

                    webClient.DownloadFile(remoteFileUrl, localDownloadUrl);
                }
                catch (Exception ex)
                {
                    var e = ex;
                }

                previewUrl.Add(remoteFileUrl);
                processedPay.Category.Add(localDownloadUrl);
                attachementsUrl.Add(localDownloadUrl);
            }

            string serviceUrl = activity.ServiceUrl;
            var channelData = activity.GetChannelData<modelsAlias::TeamsChannelData>();
            var message = Activity.CreateMessageActivity();
            message.Text = activity.Text;


            //message.Attachments = new List<Attachment>()
            //    {
            //        new Attachment
            //        {
            //            Name = "download.jpg",
            //            ContentType = "image/jpg",
            //            ContentUrl = url,
            //        }
            //    };

            //var conversationParameters = new ConversationParameters
            //{
            //    IsGroup = true,
            //    ChannelData = new modelsAlias::TeamsChannelData
            //    {
            //        Channel = new modelsAlias::ChannelInfo("19:d541e03cd2be4792a2324594fee260bc@thread.skype"),
            //    },
            //    Activity = (Activity)message
            //};

            //try
            //{                
            //    MicrosoftAppCredentials.TrustServiceUrl(serviceUrl, DateTime.MaxValue);
            //    var connectorClient = new ConnectorClient(new Uri(activity.ServiceUrl), "cc7ad832-acee-4df4-ac3a-471e180785ec", "blcKCSHN7()cbceJM2218$*");
            //    //connectorClient.HttpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("image/jpg"));
                
            //    var response = await connectorClient.Conversations.CreateConversationAsync(conversationParameters);
            //}
            //catch (Exception ex)
            //{
            //    var exc = ex;
            //}

            List<CardImage> reportImages = new List<CardImage>();
            foreach (var s in previewUrl)
            {
                reportImages.Add(new CardImage(s));
            }

            var card = new HeroCard
            {
                Title = $"Do you want to submit this {selectedEntity}?", 
                Text = 
                $"<b>Project:</b> "+processedPay.Project+" "
                + $"<br></br><b>Title:</b> "+processedPay.Title+" "
                + $"<br></br><b>Description:</b> "+processedPay.Text,
                Images = reportImages,
                Buttons = new List<CardAction>
                    {
                        new CardAction(ActionTypes.ImBack, title: "1. Submit", value: "Submit"),
                        new CardAction(ActionTypes.ImBack, title: "2. Delete", value: "Delete"),
                    },
            };
            reply.Attachments = new List<Attachment>() { card.ToAttachment() };        
        }

        public class SingleOrArrayConverter<T> : JsonConverter
        {
            public override bool CanConvert(Type objectType)
            {
                return (objectType == typeof(List<T>));
            }

            public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
            {
                JToken token = JToken.Load(reader);
                if (token.Type == JTokenType.Array)
                {
                    return token.ToObject<List<T>>();
                }
                return new List<T> { token.ToObject<T>() };
            }

            public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
            {
                List<T> list = (List<T>)value;
                if (list.Count == 1)
                {
                    value = list[0];
                }
                serializer.Serialize(writer, value);
            }

            public override bool CanWrite
            {
                get { return true; }
            }
        }

        public class AttachmentFile
        {
            public string FileName { get; set; }
            public MemoryStream Content { get; set; }
            public string ContentType { get; set; }

            [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1305:SpecifyIFormatProvider", MessageId = "System.String.Format(System.String,System.Object[])")]
            public override string ToString() =>
                $"{nameof(FileName)}: {FileName}, {nameof(ContentType)}: {ContentType}";
        }

        public class Payload
        {
            [JsonProperty("entity")]
            public string Entity { get; set; }

            [JsonProperty("project")]
            public string Project { get; set; }

            [JsonProperty("title")]
            public string Title { get; set; }

            [JsonProperty("username")]
            public string Username { get; set; }

            [JsonProperty("text")]
            public string Text { get; set; }

            [JsonProperty("severity")]
            public string Severity { get; set; }

            [JsonProperty("category")]
            [JsonConverter(typeof(SingleOrArrayConverter<string>))]
            public List<string> Category { get; set; }

            public string Id { get; set; }
            public int DialogCounter { get; set; }
            public bool HasBegun { get => hasBegun; set => hasBegun = value; }

            private bool hasBegun = false;
        }
    }
}

